<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://thepixeltribe.com
 * @since             1.0.0
 * @package           Draft
 *
 * @wordpress-plugin
 * Plugin Name:       draft portfolios
 * Plugin URI:        http://thepixeltribe.com
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.0
 * Author:            Denis Bosire
 * Author URI:        http://thepixeltribe.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       draft
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-draft-activator.php
 */
function activate_draft() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-draft-activator.php';
	Draft_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-draft-deactivator.php
 */
function deactivate_draft() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-draft-deactivator.php';
	Draft_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_draft' );
register_deactivation_hook( __FILE__, 'deactivate_draft' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-draft.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_draft() {

	$plugin = new Draft();
	$plugin->run();

}
run_draft();

//require plugin_dir_path( __FILE__ ) . 'includes/cpt.php';
require plugin_dir_path( __FILE__ ) . 'includes/cpt.php';

/**
 * Get the bootstrap!
 */
if ( file_exists(  __DIR__ . '/cmb2/init.php' ) ) {
  require_once  __DIR__ . '/cmb2/init.php';
} elseif ( file_exists(  __DIR__ . '/CMB2/init.php' ) ) {
  require_once  __DIR__ . '/CMB2/init.php';
}

// Custom Meta Boxes

add_action( 'cmb2_admin_init', 'cmb2_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 */
function cmb2_sample_metaboxes() {

    // Start with an underscore to hide fields from custom fields list
    $prefix = '_draft_';

    /**
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'test_metabox',
        'title'         => __( 'Portfolio Details', 'cmb2' ),
        'object_types'  => array( 'draft_portfolio', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );
$cmb->add_field( array(
    'name' => 'Image Gallery',
    'desc' => '',
    'id'         => $prefix . 'image_gallery',
    'type' => 'file_list',
    // 'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
    // Optional, override default text strings
    'text' => array(
        'add_upload_files_text' => 'Add Images', // default: "Add or Upload Files"
        'remove_image_text' => 'Remove Images', // default: "Remove Image"
        'file_text' => 'Image', // default: "File:"
    ),
) );

    // Regular text field
    $cmb->add_field( array(
        'name'       => __( 'Date', 'cmb2' ),
        'desc'       => __( 'When was this Work done?', 'cmb2' ),
        'id'         => $prefix . 'date',
        'type'       => 'text_date',
        //'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
        // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
        // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
        // 'on_front'        => false, // Optionally designate a field to wp-admin only
        // 'repeatable'      => true,
    ) );

    // URL text field
    $cmb->add_field( array(
        'name' => __( 'Your Role', 'cmb2' ),
        'desc' => __( 'Your Role in the Project', 'cmb2' ),
        'id'   => $prefix . 'role',
        'type' => 'text',
        // 'protocols' => array('http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet'), // Array of allowed protocols
        // 'repeatable' => true,
    ) );

    // Email text field
    $cmb->add_field( array(
        'name' => __( 'Client', 'cmb2' ),
        'desc' => __( '', 'cmb2' ),
        'id'   => $prefix . 'client',
        'type' => 'text',
        // 'repeatable' => true,
    ) );

    // Add other metaboxes as needed

}