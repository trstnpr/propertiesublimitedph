=== Draft Portfolios ===
Contributors: Denis Bosire
Donate link: http://thepixeltribe.com
Tags: portfolio
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

Draft Portfolio helps you build amazing sites for your works, give it a go!
== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `draft.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place `<?php do_action('plugin_name_hook'); ?>` in your templates

== Frequently Asked Questions ==

= Is this Plugin Free? =

No, this plugin is supplied as part of a premium WordPress theme.

= How Much does it cost? =

$35, plus the PRO theme

= How Many sites can I use this theme on? =
One licence = Unlimited sites :) 


== Changelog ==
